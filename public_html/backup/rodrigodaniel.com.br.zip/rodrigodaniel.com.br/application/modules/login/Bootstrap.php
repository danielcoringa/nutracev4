<?php
class Login_Bootstrap extends Zend_Application_Module_Bootstrap
{
 
    protected function _init(){
        //
              
        
    }
    protected function _initTranslate() {
		$translator = new Zend_Translate ( array (
			'adapter' => 'csv', 
			'content' => APPLICATION_PATH ."/data/locales", 
			'locale' => 'pt_BR', 
                        'disableNotices' => 'true',
			'scan' => Zend_Translate::LOCALE_DIRECTORY 
		) );
		Zend_Validate_Abstract::setDefaultTranslator ( $translator );
	}  
    
}