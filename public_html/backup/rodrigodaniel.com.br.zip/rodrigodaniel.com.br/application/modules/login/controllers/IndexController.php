<?php

class Login_IndexController extends Coringa_Controller_Alicerce_Action {

    public function init() {
        /* Initialize action controller here */

        parent::init();
        parent::tables();
        parent::forms();
    }

    public function indexAction() {
        // action body
        // action body

        $request = $this->_request;
        $errorv = $this->getRequest()->getParam('error');
        $this->view->controle = $this->getRequest()->getParam('origem');


        if (isset($errorv)) {

            // $this->_helper->FlashMessenger(array("alert alert-error" => "Acesso Restrito. Sem Permissão."));
        }
        if ($request->isPost()) {
            $data = $request->getPost();

            $login = Login_Model_Login::setLogin($data['login_name'], $data['login_pw']);

            if (is_array($login)) {
                // Faz conexao com o banco de dados e pega os dados do usuario
                $authNamespace = new Zend_Session_Namespace("auth");
                $authNamespace->users = true;
                $authNamespace->user_id = $login[0]['cod_usuario'];
                $authNamespace->username = $login[0]['nom_usuario'];
                $authNamespace->user_pwd = $login[0]['des_senha'];
                $authNamespace->grupo_id = $login[0]['cod_grupo'];
                $authNamespace->cod_empresa = $login[0]['cod_empresa'];
                $authNamespace->role = strtolower($login[0]['nom_grupo']);

                $this->norenderall();

                $this->_redirect('/');
                exit;
            }
            else {
                $authNamespace = new Zend_Session_Namespace("auth");
                $authNamespace->users = false;
                $this->_helper->FlashMessenger(array("alert alert-error" => $login));
            }
        }
    }

    public function logoutAction() {


        //$this->log->info("Saiu do Sistema.");
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(TRUE);
        session_destroy();
        $this->_redirect('/');
    }

}
