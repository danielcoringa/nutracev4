<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Blog_ArtigosController extends Coringa_Controller_Blog_Action {

    public function init() {
        parent::init();
    }

    public function indexAction() {

    }

    public function vAction() {
        $params = $this->getRequest()->getParams();
        $db = new Admin_Model_DbTable_Artigo();
        $dbc = new Admin_Model_DbTable_Conf_Artigo();


        $this->view->conf = $dbc->getDados($params['code']);
        $this->view->data = $db->getDados($params['code']);
    }

    public function pageAction() {
        $this->noLayout();
        $this->noRender();
    }

    public function categoriaAction() {
        $params = $this->getRequest()->getParams();
        $db = new Admin_Model_DbTable_Artigo();
        $dbc = new Admin_Model_DbTable_CategoriaArtigo();
        $select = $dbc->select();
        $select->where("cod_categoria=?", $params['code']);
        $result = $dbc->fetchAll($select)->toArray();
        $select2 = $db->select();

        foreach ($result as $row) {

            $select2->orwhere("cod_artigo=" . $row['cod_artigo'] . " AND ind_status='A'");
        }
        //  die($select2->__toString());
        $result2 = $db->fetchAll($select2)->toArray();


        $this->view->data = $result2;
    }

}
