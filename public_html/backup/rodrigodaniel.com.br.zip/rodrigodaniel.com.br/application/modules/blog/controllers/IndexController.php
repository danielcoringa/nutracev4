<?php

class Blog_IndexController extends Coringa_Controller_Blog_Action {

    public function init() {
        parent::init();
    }

    public function indexAction() {
        $db = new Admin_Model_DbTable_Artigo();


        $select = $db->select();
        $select->where("ind_status='A'");
        $select->order("cod_artigo DESC");
        $result = $db->fetchAll($select);
        $total = count($result);
        $limite = 6;
        $offset = ceil($total / $limite);
        $this->view->pages = $offset;
        $this->view->data = $db->getArtigos('ind_status="A"');
    }

}
