<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Blog_FormatoController extends Coringa_Controller_Blog_Action {

    public function init() {
        parent::init();
    }

    public function imagemAction() {

    }

    public function galeriaAction() {

    }

    public function audioAction() {

    }

    public function videoAction() {

    }

    public function chatAction() {

    }

    public function citacaoAction() {

    }

    public function revisaoAction() {

    }

}
