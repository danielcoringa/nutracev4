<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Blog_ModeController extends Coringa_Controller_Blog_Action {

    public function init() {
        $this->_helper->layout->disableLayout();
        //$this->_helper->viewRenderer->setNoRender(TRUE);
    }

    public function pageAction() {
        $this->noLayout();
        $this->noRender();
        $params = $this->getRequest()->getParams();
        $db = new Admin_Model_DbTable_Artigo();
        $dbc = new Admin_Model_DbTable_Conf_Artigo();
        $select = $db->select();
        $select->where("ind_status='A'");
        $select->order("cod_artigo DESC");
        $result = $db->fetchAll($select);
        $total = count($result);
        $limite = $params['col'] * 2;
        $offset = ceil($total / $limite);
        $pg = $params['p'];
        $select->limitPage($pg, $limite);
        $result = $db->fetchAll($select);
        echo "<h1>" . $params['p'] . "</h1>";

        $this->view->conf = $dbc->getDados($params['code']);
        $this->view->data = $result;
        $this->render('page');
    }

    public function magazineAction() {

    }

}
