<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_Related extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function related($cod) {
        $db = new Admin_Model_DbTable_CategoriaArtigo();
        $result = $db->getDados($cod);
        foreach ($result as $row) {
            $select = $db->select();
            $select->where("cod_categoria=?", $row['cod_categoria']);
            $resulta = $db->fetchAll($select);
            foreach ($resulta as $rowa) {
                $dados[] = $rowa['cod_artigo'];
            }
        }
        $dba = new Admin_Model_DbTable_Artigo();
        $selectr = $dba->select();
        $selectr->where("ind_status='A'");
        foreach ($dados as $dado) {
            $selectr->orWhere("cod_artigo=?", $dado);
        }
        $selectr->limit(4);
        $resultr = $dba->fetchAll($selectr)->toArray();

        return $resultr;
    }

    private function urlAmigavel($string) {
        $string = preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities($string));
        $string = strip_tags(trim($string));

        /* Agora, remove qualquer espaço em branco duplicado */
        $string = preg_replace('/\s(?=\s)/', '', $string);

        /* Ssubstitui qualquer espaço em branco (não-espaço), com um espaço */
        $string = preg_replace('/[\n\r\t]/', ' ', $string);

        /* Remove qualquer espaço vazio */
        $string = str_replace("/", " ", $string);
        $string = str_replace(" ", "-", $string);
        $string = str_replace(",", "_", $string);
        $string = str_replace(".", "_", $string);
        return strtolower($string);
    }

}
