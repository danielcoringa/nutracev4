<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_SearchMedia extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function searchMedia($cod, $mode = 'img', $service = null) {
        $db = new Admin_Model_DbTable_Artigo();
        $dados = $db->getDados($cod);
        $dd = str_replace("<iframe", "||<iframe", $dados['des_artigo']);
        $iframes = explode("||", $dd);
        $x = 0;
        foreach ($iframes as $if) {
            if (stristr($if, 'iframe')) {
                preg_match('/<iframe.*src=\"(.*)\".*><\/iframe>/isU', $if, $matches);
                $iframe[] = $matches;
                if (stristr($matches[1], 'youtube')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'youtube';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'vimeo')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'vimeo';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'soundcloud')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'soundcloud';
                    $widget[$x]['link'] = $matches[1];
                }
            }
            $x++;
        }
        // Verifica por Embeds
        $dd = str_replace("<embed", "||<embed", $dados['des_artigo']);
        $embeds = explode("||", $dd);

        foreach ($embeds as $if) {
            if (stristr($if, '<embed')) {
                preg_match('/<embed.+?src="(.+?)".+?<\/embed>/', $if, $matches);
                $embed[] = $matches;
                if (stristr($matches[1], 'youtube')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'youtube';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'vimeo')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'vimeo';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'soundcloud')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'soundcloud';
                    $widget[$x]['link'] = $matches[1];
                }
            }
            $x++;
        }
        // Verifica por Imagens
        $dd = str_replace("<img", "||<img", $dados['des_artigo']);
        $imgs = explode("||", $dd);

        foreach ($imgs as $if) {
            if (stristr($if, '<img')) {
                preg_match("/<img .*?(?=src)src=\"([^\"]+)\"/si", $if, $matches);
                $img[] = $matches;
                $widget[$x]['tipo'] = 'img';
                $widget[$x]['service'] = 'imagem';
                $widget[$x]['link'] = $matches[1];
            }
            $x++;
        }
        $block = $widget[$this->recursive_array_search($service, $widget)];
        switch ($block['tipo']) {
            case 'iframe':
                $html.='<iframe src="' . $block['link'] . 'width="100%" height="100%" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                break;
            case 'embed':
                $html.='<embed width="100%" height="100%" src="' . $block['link'] . '" type="application/x-shockwave-flash" allowFullScreen="true"> </embed>';
                break;
            case 'img':
                $img_link = $block['link'];
                $img_link = str_replace("_large", "", $img_link);
                $img_link = str_replace("_small", "", $img_link);
                $img_link = str_replace("_medium", "", $img_link);
                $img_link = str_replace("_thumb", "", $img_link);
                $ext_link = substr($img_link, -3);
                $file_link = str_replace('.' . $ext_link, '', $img_link) . '_thumb';
                $html.= '<a href="' . $block['link'] . '" data-rel="prettyPhoto">';
                $html.= '<img src="' . $file_link . '.' . $ext_link . '" alt="" /></a>';
                break;
            default:
                $html = '';
                break;
        }
        return $html;
    }

    function recursive_array_search($needle, $haystack) {
        foreach ($haystack as $key => $value) {
            $current_key = $key;
            if ($needle === $value OR (is_array($value) && $this->recursive_array_search($needle, $value) !== false)) {
                return $current_key;
            }
        }
        return false;
    }

}
