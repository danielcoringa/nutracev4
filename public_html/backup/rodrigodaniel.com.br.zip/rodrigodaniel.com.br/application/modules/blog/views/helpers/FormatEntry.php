<?php

class Zend_View_Helper_FormatEntry extends Zend_View_Helper_Abstract {

    public function formatEntry($cod) {
        if ($cod > 0) {
            $dba = new Admin_Model_DbTable_Artigo();
            $dados = $dba->getDados($cod);
            switch ($dados['tipo_artigo']) {
                case 'image':
                    $html.='<div class="overlay-image"></div>';
                    $html.='<a data-rel="prettyPhoto" href="' . $this->miniatura($cod) . '" title="' . $dados['nom_artigo'] . '" class="zoom-img">';
                    $html.='<i class = "fa fa-plus"></i></a>';
                    $html.='<a href="#">';
                    $html.='<img src="' . $this->miniatura($cod, 'medium') . '" ';
                    $html.='title="' . $dados['nom_artigo'] . '" alt="' . $dados['nom_artigo'] . '" /></a>';
                    break;
                case 'gallery':
                    $html.='<div class="overlay-image"></div>';
                    $gal = $this->galeria($cod);
                    $ggal = $gal;
                    rsort($ggal);
                    $x = md5(microtime());
                    foreach ($ggal as $galeria) {
                        $html.='<a data-rel="prettyPhoto[gal' . $x . ']" href="' . BASE_URL . $galeria['nom_pasta'] . $galeria['nom_imagem'] . '_big.' . $galeria['ext_imagem'] . '" title="' . $dados['nom_artigo'] . '" class="zoom-img">';
                    }
                    $html.='<i class = "fa fa-plus"></i></a>';
                    $html.='<a href="#">';

                    $html.='<img src="' . BASE_URL . $gal[0]['nom_pasta'] . $gal[0]['nom_imagem'] . '_gallery.' . $gal[0]['ext_imagem'] . '" ';
                    $html.='title="' . $dados['nom_artigo'] . '" alt="' . $dados['nom_artigo'] . '" /></a>';
                    $script = '<script type="text/javascript">'
                            . 'jQuery.noConflict()(function($) {'
                            . '$(window).load(function() {'
                            . '$("a[rel^=\'prettyPhoto\']").prettyPhoto({'
                            . 'animationSpeed: \'normal\','
                            . 'opacity: 0.80,'
                            . 'showTitle: true,'
                            . 'theme: \'light_square\','
                            . 'deeplinking: false'
                            . '});'
                            . '$("#slider-104-318277304").flexslider({'
                            . 'animation: "fade",'
                            . 'directionNav: true,'
                            . 'controlNav: false,'
                            . 'slideshow: true,'
                            . 'smoothHeight: true'
                            . '});'
                            . '});'
                            . '$("a[rel^=\'prettyPhoto\']").prettyPhoto({'
                            . 'animationSpeed: \'normal\','
                            . 'opacity: 0.80,'
                            . 'showTitle: true,'
                            . 'theme: \'light_square\','
                            . 'deeplinking: false'
                            . '});'
                            . '});'
                            . '</script>';
                    break;
                case 'video':
                    $html.=$this->getVideo($cod);
                    break;
                case 'audio':
                    $html.=$this->getAudio($cod);
                    break;
                default:
                    $html.=$this->searchMedia($cod, 'img');
                    break;
            }
        }
        return $html . $script;
    }

    public function miniatura($cod, $type = '') {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Imagem();
            $dados = $db->getDados($cod);
            switch ($dados['img_tipo']) {
                case 'server':
                    $arquivo = '/' . $dados['img_name'];
                    $ext = substr($arquivo, -3);
                    $arq = str_replace("." . $ext, '', $arquivo);
                    $thumb = $arq . '_thumb.' . $ext;
                    $medium = $arq . '_medium.' . $ext;
                    $list = $arq . '_list.' . $ext;
                    break;
                case 'flickr':
                    $arquivo = $dados['img_name'];
                    $ext = substr($arquivo, -3);
                    $arq = str_replace("." . $ext, '', $arquivo);
                    $arq = substr($arq, 0, -2);
                    $thumb = $arq . '.' . $ext;
                    $list = $arq . '_s.' . $ext;
                    $medium = $arq . '_c.' . $ext;
                    break;
                case 'google':
                    $arquivo = $dados['img_name'];
                    $thumb = $dados['img_thumb'];
                    $medium = $dados['img_name'];
                    $list = $thumb;
                    break;
            }
            switch ($type) {
                case "medium":
                    return $medium;
                    break;
                case "thumb":
                    return $thumb;
                    break;
                case "list":
                    return $list;
                    break;
                default:
                    return $arquivo;
                    break;
            }
        }
        else {
            return 'img/no-image.jpg';
        }
    }

    private function galeria($cod) {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Galeria();
            $dados = $db->getDados($cod);
            return $dados;
        }
    }

    private function getVideo($cod) {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Video();
            $dados = $db->getDados($cod);
            if ($dados[0]['tipo_video'] == 'youtube') {
                return '<embed width = "100%" height = "100%" src = "http://www.youtube.com/v/' . $dados[0]['id_video'] . '&autoplay=0&rel=0&showinfo=0" type = "application/x-shockwave-flash" allowFullScreen = "true"> </embed>';
            }
            else {
                return '<iframe src = "//player.vimeo.com/video/' . $dados[0]['id_video'] . '?autoplay=0" width = "100%" height = "100%" frameborder = "0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
            }
        }
    }

    private function getAudio($cod, $mode = 'false') {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Audio();
            $dados = $db->getDados($cod);
            return '<iframe width = "100%" height = "166" scrolling = "no" frameborder = "no" src = "https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . $dados['id_musica'] . '&amp;color=ff6600&amp;auto_play=' . $mode . '&amp;show_artwork=true"></iframe>';
        }
    }

    public function searchMedia($cod, $service = null) {
        $db = new Admin_Model_DbTable_Artigo();
        $dados = $db->getDados($cod);
        $dd = str_replace("<iframe", "||<iframe", $dados['des_artigo']);
        $iframes = explode("||", $dd);
        $x = 0;
        foreach ($iframes as $if) {
            if (stristr($if, 'iframe')) {
                preg_match('/<iframe.*src=\"(.*)\".*><\/iframe>/isU', $if, $matches);
                $iframe[] = $matches;
                if (stristr($matches[1], 'youtube')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'youtube';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'vimeo')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'vimeo';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'soundcloud')) {
                    $widget[$x]['tipo'] = 'iframe';
                    $widget[$x]['service'] = 'soundcloud';
                    $widget[$x]['link'] = $matches[1];
                }
            }
            $x++;
        }
        // Verifica por Embeds
        $dd = str_replace("<embed", "||<embed", $dados['des_artigo']);
        $embeds = explode("||", $dd);

        foreach ($embeds as $if) {
            if (stristr($if, '<embed')) {
                preg_match('/<embed.+?src="(.+?)".+?<\/embed>/', $if, $matches);
                $embed[] = $matches;
                if (stristr($matches[1], 'youtube')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'youtube';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'vimeo')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'vimeo';
                    $widget[$x]['link'] = $matches[1];
                }
                if (stristr($matches[1], 'soundcloud')) {
                    $widget[$x]['tipo'] = 'embed';
                    $widget[$x]['service'] = 'soundcloud';
                    $widget[$x]['link'] = $matches[1];
                }
            }
            $x++;
        }
        // Verifica por Imagens
        $dd = str_replace("<img", "||<img", $dados['des_artigo']);
        $imgs = explode("||", $dd);

        foreach ($imgs as $if) {
            if (stristr($if, '<img')) {
                preg_match("/<img .*?(?=src)src=\"([^\"]+)\"/si", $if, $matches);
                $img[] = $matches;
                $widget[$x]['tipo'] = 'img';
                $widget[$x]['service'] = 'imagem';
                $widget[$x]['link'] = $matches[1];
            }
            $x++;
        }
        $block = $widget[$this->recursive_array_search($service, $widget)];
        switch ($block['tipo']) {
            case 'iframe':
                $html.='<iframe src="' . $block['link'] . 'width="100%" height="100%" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                break;
            case 'embed':
                $html.='<embed width="100%" height="100%" src="' . $block['link'] . '" type="application/x-shockwave-flash" allowFullScreen="true"> </embed>';
                break;
            case 'img':
                $img_link = $block['link'];
                $img_link = str_replace("_large", "", $img_link);
                $img_link = str_replace("_small", "", $img_link);
                $img_link = str_replace("_medium", "", $img_link);
                $img_link = str_replace("_thumb", "", $img_link);
                $ext_link = substr($img_link, -3);
                $file_link = str_replace('.' . $ext_link, '', $img_link) . '_medium';
                $fb = str_replace("index.php", "", $_SERVER['SCRIPT_FILENAME']);
                $fs = $fb . $file_link . '.' . $ext_link;
                if (!is_file($fs)) {
                    $file_link = str_replace('.' . $ext_link, '', $img_link);
                    $file_link = substr($file_link, 0, -2) . '_c';
                };
                $html.= '<a href="' . $block['link'] . '" data-rel="prettyPhoto">';
                $html.= '<img src="' . $file_link . '.' . $ext_link . '" alt="" /></a>';
                break;
            default:
                $html = '';
                break;
        }
        return $html;
    }

    function recursive_array_search($needle, $haystack) {
        foreach ($haystack as $key => $value) {
            $current_key = $key;
            if ($needle === $value OR (is_array($value) && $this->recursive_array_search($needle, $value) !== false)) {
                return $current_key;
            }
        }
        return false;
    }

}
