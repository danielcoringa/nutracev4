<?php
class Zend_View_Helper_UrlAmigavel extends Zend_View_Helper_Abstract
{
	public function urlamigavel($string){
         $string = preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities($string));   
	 $string = strip_tags(trim($string));
	
	/*Agora, remove qualquer espaço em branco duplicado*/
	$string = preg_replace('/\s(?=\s)/', '', $string);
	
	/*Ssubstitui qualquer espaço em branco (não-espaço), com um espaço*/
	$string = preg_replace('/[\n\r\t]/', ' ', $string);
	
	/*Remove qualquer espaço vazio*/
	$string = str_replace("/"," ",$string);
	$string = str_replace(" ","-",$string);
	$string = str_replace(",","_",$string);
	$string = str_replace(".","_",$string);
	return strtolower($string);
	}


	
}