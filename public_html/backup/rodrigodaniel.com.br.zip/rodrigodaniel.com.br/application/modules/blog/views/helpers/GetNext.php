<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_GetNext extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function getNext($cod) {
        $db = new Admin_Model_DbTable_Artigo();
        $select = $db->select();
        $select->where('cod_artigo>?', $cod);
        $select->where('ind_status="A"');
        $select->order('cod_artigo ASC');
        $result = $db->fetchRow($select);
        if (count($result) > 0) {
            $html = '<a href="/artigos/v/titulo/' . $this->urlAmigavel($result['nom_artigo']) . '/code/' . $result['cod_artigo'] . '" rel="next">';
            $html.= '<span class="fa fa-chevron-right" title="Próximo"></span>';
            $html.= '</a>';
        }
        return $html;
    }

    private function urlAmigavel($string) {
        $string = preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities($string));
        $string = strip_tags(trim($string));

        /* Agora, remove qualquer espaço em branco duplicado */
        $string = preg_replace('/\s(?=\s)/', '', $string);

        /* Ssubstitui qualquer espaço em branco (não-espaço), com um espaço */
        $string = preg_replace('/[\n\r\t]/', ' ', $string);

        /* Remove qualquer espaço vazio */
        $string = str_replace("/", " ", $string);
        $string = str_replace(" ", "-", $string);
        $string = str_replace(",", "_", $string);
        $string = str_replace(".", "_", $string);
        return strtolower($string);
    }

}
