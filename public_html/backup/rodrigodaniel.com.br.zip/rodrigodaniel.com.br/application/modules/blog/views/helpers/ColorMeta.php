<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_ColorMeta extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function colorMeta($cod) {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Conf_Artigo();
            $dados = $db->getDados($cod);

            return $dados['bgcolor_meta'];
        }
    }

    private function nameCat($cod) {
        $dbc = new Admin_Model_DbTable_Categoria();
        $dbcd = $dbc->getDados($cod);
        return $dbcd['nom_categoria'];
    }

}
