<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_GetStar extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function getStar($val) {
        switch ($val) {
            case 0.5:
                $html = '<i class="fa fa-star-half"></i>';
                break;
            case 1:
                $html = '<i class="fa fa-star"></i>';
                break;
            case 1.5:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star-half"></i>';
                break;
            case 2:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                break;
            case 2.5:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star-half"></i>';
                break;
            case 3:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                break;
            case 3.5:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star-half"></i>';
                break;
            case 4:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                break;
            case 4.5:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star-half"></i>';
                break;
            case 5:
                $html = '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                $html.= '<i class="fa fa-star"></i>';
                break;
            default:
                $html = '';
                break;
        }
        return $html;
    }

}
