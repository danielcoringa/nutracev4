<?php

class Zend_View_Helper_EntryWelcome extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function entryWelcome($params) {
        if ($params['code'] > 0) {
            switch ($params['action']) {
                case 'v':
                    $dba = new Admin_Model_DbTable_Artigo();
                    $dados = $dba->getDados($params['code']);
                    $html = '<div class="entry-welcome">'
                            . '<div class="row">'
                            . '<div class="col-lg-6">'
                            . '<h1 class="archive-title  title_left">'
                            . $dados['nom_artigo']
                            . '</h1>'
                            . '<ul class="breadcrumb-list clearfix">'
                            . '<li>'
                            . '<a href="/">'
                            . 'Principal'
                            . '</a>'
                            . '/'
                            . '</li>'
                            . '<li>'
                            . '<a href="/artigos/categoria/t/'
                            . $this->urlAmigavel($this->categoriaNome($dados['cod_artigo']))
                            . '/code/'
                            . $this->categoriaCode($dados['cod_artigo'])
                            . '" '
                            . 'title="'
                            . $this->categoriaNome($dados['cod_artigo'])
                            . '">'
                            . $this->categoriaNome($dados['cod_artigo'])
                            . '</a>'
                            . '/'
                            . '</li>'
                            . '<li>'
                            . $dados['nom_artigo']
                            . '</li>'
                            . '</ul>'
                            . '</div>'
                            . '<div class="col-lg-6">'
                            . '<nav class="nav-single clearfix">'
                            . '<h3 class="assistive-text">Navegador de Artigos</h3>'
                            . '<span class="nav-previous">'
                            . $this->getPrev($dados['cod_artigo'])
                            . '</span>'
                            . '<span class="nav-next">'
                            . $this->getNext($dados['cod_artigo'])
                            . '</span>'
                            . '</nav>'
                            . '<div class="clear"></div>'
                            . '</div>'
                            . '</div>'
                            . '</div>';
                    break;
                case 'categoria':
                    $dbc = new Admin_Model_DbTable_Categoria();
                    $dados = $dbc->getDados($params['code']);
                    $html = '<div class="entry-welcome">'
                            . '<div class="row">'
                            . '<div class="col-lg-6">'
                            . '<h1 class="archive-title title_left">'
                            . 'Categoria de Artigos: ' . $dados['nom_categoria']
                            . '</h1>'
                            . '<p>'
                            . $dados['des_categoria']
                            . '</p>'
                            . '<div class="clear"></div>'
                            . '</div>'
                            . '</div>'
                            . '</div>';
                    break;
                default:
                    $html = '';
                    break;
            }
            return $html;
        }
    }

    public function urlamigavel($string) {
        $string = preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities($string));
        $string = strip_tags(trim($string));

        /* Agora, remove qualquer espaço em branco duplicado */
        $string = preg_replace('/\s(?=\s)/', '', $string);

        /* Ssubstitui qualquer espaço em branco (não-espaço), com um espaço */
        $string = preg_replace('/[\n\r\t]/', ' ', $string);

        /* Remove qualquer espaço vazio */
        $string = str_replace("/", " ", $string);
        $string = str_replace(" ", "-", $string);
        $string = str_replace(",", "_", $string);
        $string = str_replace(".", "_", $string);
        return strtolower($string);
    }

    public function categoriaNome($cod) {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_CategoriaArtigo();
            $dados = $db->getDados($cod);

            return $this->nameCat($dados[0]['cod_categoria']);
        }
    }

    public function categoriaCode($cod) {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_CategoriaArtigo();
            $dados = $db->getDados($cod);

            return $dados[0]['cod_categoria'];
        }
    }

    public function getPrev($cod) {
        $db = new Admin_Model_DbTable_Artigo();
        $select = $db->select();
        $select->where('cod_artigo<?', $cod);
        $select->where('ind_status="A"');
        $select->order('cod_artigo DESC');
        $result = $db->fetchRow($select);
        if (count($result) > 0) {
            $html = '<a href="/artigos/v/titulo/' . $this->urlAmigavel($result['nom_artigo']) . '/code/' . $result['cod_artigo'] . '" rel="prev">';
            $html.= '<span class="fa fa-chevron-left" title="Anterior"></span>';
            $html.= '</a>';
        }
        return $html;
    }

    public function getNext($cod) {
        $db = new Admin_Model_DbTable_Artigo();
        $select = $db->select();
        $select->where('cod_artigo>?', $cod);
        $select->where('ind_status="A"');
        $select->order('cod_artigo ASC');
        $result = $db->fetchRow($select);
        if (count($result) > 0) {
            $html = '<a href="/artigos/v/titulo/' . $this->urlAmigavel($result['nom_artigo']) . '/code/' . $result['cod_artigo'] . '" rel="next">';
            $html.= '<span class="fa fa-chevron-right" title="Próximo"></span>';
            $html.= '</a>';
        }
        return $html;
    }

    private function nameCat($cod) {
        $dbc = new Admin_Model_DbTable_Categoria();
        $dbcd = $dbc->getDados($cod);
        return $dbcd['nom_categoria'];
    }

}
