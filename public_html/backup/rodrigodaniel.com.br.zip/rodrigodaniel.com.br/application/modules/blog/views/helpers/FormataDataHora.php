<?php

class Zend_View_Helper_FormataDataHora extends Zend_View_Helper_Abstract {

    public function formataDataHora($date) {
        $date = strtotime($date);
        $granularity = 1;
        $difference = time() - $date;
        $periods = array('década' => 315360000,
            'ano' => 31536000,
            'mês' => 2628000,
            'semana' => 604800,
            'dia' => 86400,
            'hora' => 3600,
            'minuto' => 60,
            'segundo' => 1);

        foreach ($periods as $key => $value) {
            if ($difference >= $value) {
                $time = floor($difference / $value);
                $difference %= $value;
                $retval .= ($retval ? ' ' : '') . $time . ' ';
                $retval .= (($time > 1) ? $key . 's' : $key);
                $granularity--;
            }
            if ($granularity == '0') {
                break;
            }
        }
        return $retval . ' atrás';
    }

}

?>
