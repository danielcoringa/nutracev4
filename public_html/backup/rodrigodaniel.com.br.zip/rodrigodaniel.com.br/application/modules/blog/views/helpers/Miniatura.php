<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Zend_View_Helper_Miniatura extends Zend_View_Helper_Abstract {

    public function init() {

    }

    public function miniatura($cod, $type = '') {
        if ($cod > 0) {
            $db = new Admin_Model_DbTable_Imagem();
            $dados = $db->getDados($cod);
            switch ($dados['img_tipo']) {
                case 'server':
                    $arquivo = '/' . $dados['img_name'];
                    $ext = substr($arquivo, -3);
                    $arq = str_replace("." . $ext, '', $arquivo);
                    $thumb = $arq . '_thumb.' . $ext;
                    $medium = $arq . '_medium.' . $ext;
                    $list = $arq . '_list.' . $ext;
                    break;
                case 'flickr':
                    $arquivo = $dados['img_name'];
                    $ext = substr($arquivo, -3);
                    $arq = str_replace("." . $ext, '', $arquivo);
                    $arq = substr($arq, 0, -2);
                    $thumb = $arq . '.' . $ext;
                    $list = $arq . '_s.' . $ext;
                    $medium = $arq . '_c.' . $ext;
                    break;
                case 'google':
                    $arquivo = $dados['img_name'];
                    $thumb = $dados['img_thumb'];
                    $medium = $dados['img_name'];
                    $list = $thumb;
                    break;
            }
            switch ($type) {
                case "medium":
                    return $medium;
                    break;
                case "thumb":
                    return $thumb;
                    break;
                case "list":
                    return $list;
                    break;
                default:
                    return $arquivo;
                    break;
            }
        }
        else {
            return 'img/no-image.jpg';
        }
    }

}
