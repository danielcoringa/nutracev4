<?php

/**
 * Description of Security
 * @category   PublicAnuncios
 * @package    Coringa_Controller
 * @copyright  Copyright (c) 2013-2013 CoringaSistemas INC (http://www.coringasistemas.com.br)
 */
class Cursos_GridController extends Coringa_Controller_Cursos_Action {

    public function init() {
        parent::init();
        parent::norender();
        $this->_helper->viewRenderer->setNoRender(TRUE);
        $iTotal = 0;
        $iFilteredTotal = 0;
        $this->output = array(
            "sEcho" => intval($_GET['sEcho']),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array()
        );
    }

    public function listAction() {
        $params = $this->getRequest()->getParams();
        $this->$params['t']();
        echo json_encode($this->output);
    }

    private function categorias() {
        $db = new Cursos_Model_DbTable_Categoria();
        $retorno = $db->gridList('A');
        foreach ($retorno as $row) {
            $rows = array(
                '<input type="checkbox" class="optcheck" value="' . $row['cod_categoria'] . '" />',
                $this->setFullField($row['nom_categoria']),
                $this->setFullField($row['nom_categoria_pai']),
                $row['des_categoria'],
                $this->showStatus($row['ind_status'])
            );
            $this->output['aaData'][] = $rows;
        }
    }

    private function instrutores() {
        $db = new Cursos_Model_DbTable_Instrutor();
        $retorno = $db->gridList('A');
        foreach ($retorno as $row) {
            $rows = array(
                '<input type="checkbox" class="optcheck" value="' . $row['cod_instrutor'] . '" />',
                $this->setFullField($row['nom_instrutor']),
                $this->setFullField($row['end_email']),
                $row['ind_cidade'] . '/' . $row['ind_estado'],
                $row['ind_pais'],
                $row['num_telefone'],
                $this->showStatus($row['ind_status'])
            );
            $this->output['aaData'][] = $rows;
        }
    }

    private function dataFormat($d) {
        $dt = explode(" ", $d);
        $dt = explode("-", $dt[0]);
        return $dt[2] . '/' . $dt[1] . '/' . $dt[0];
    }

    private function returnDias($data1, $data2) {
        //Instancia a classe, atribuindo a data inicial
        list($d1, $h1) = explode(' ', $data1);
        list($d2, $h2) = explode(' ', $data2);
        $dataInicio = new DateTime($d1);
        $dataFim = new DateTime($d2);
        //Retorna a diferença entre dois objetos DateTime, no caso um objeto DataInterval
        $intervalo = $dataInicio->diff($dataFim);
        //Agora formatamos a data em dias
        return str_pad($intervalo->format('%d'), 2, '0', 0);
    }

    private function setFullField($var) {
        return '<div class="campo_full">' . $var . '</div>';
    }

    private function setMiddleField($var) {
        return '<div class="campo_middle">' . $var . '</div>';
    }

    private function showThumb($val) {
        $db = new Admin_Model_DbTable_Imagem();
        $sel = $db->select();
        $sel->where("cod_equipamento=?", $val);
        $ret = $db->fetchRow($sel);
        $imagem = str_replace(BASIC_FOLDER . "/media/", "", $ret["link_imagem"]);
        $img_arr = explode(".", $imagem);
        $img_name = $img_arr[0];
        $img_ext = $img_arr[1];
        $thumb = '/media/' . $img_name . '_thumb.' . $img_ext;
        return "<img src='{$thumb}' />";
    }

    private function showStatus($val) {
        $retorno = array("A" => "Ativo", "I" => "Inativo");
        $classe = array("A" => "active", "I" => "inactive");
        $icon = array("A" => '<span class="icon-ok-circle"></span>&nbsp;', "I" => '<span class="icon-ban-circle"></span>&nbsp;');
        $html = '<div class="' . $classe[$val] . '">' . $icon[$val] . $retorno[$val] . '</div>';
        return $html;
    }

    public function removeAction() {
        $params = $this->getRequest()->getPost();
        $local = ucfirst($this->depluralize($params['table']));
        $campo = 'cod_' . strtolower($local);
        $dbt = 'Cursos_Model_DbTable_' . $local;
        $db = new $dbt();
        foreach ($params['ids'] as $id) {
            $update = $db->update(array("ind_status" => "E"), $campo . '=' . $id);
        }
        echo "removeSelRows();";
        echo "$.gritter.add({
		title:	'Registros Excluídos',
		text:	'Os registros selecionados foram excluídos com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
    }

    public function updateAction() {
        $params = $this->getRequest()->getPost();
        $local = ucfirst($this->depluralize($params['table']));
        $campo = 'cod_' . strtolower($local);
        $dbt = 'Cursos_Model_DbTable_' . $local;
        $db = new $dbt();
        $x = 0;
        foreach ($params['ids'] as $id) {
            $sel = $db->select();
            $sel->where($campo . '=' . $id);
            $ret = $db->fetchRow($sel);
            $val_status = $ret['ind_status'];
            if ($val_status === 'A') {
                $update = $db->update(array("ind_status" => "I"), $campo . '=' . $id);
                echo "updateSelRows('inativo',{$x});";
            }
            else {
                $update = $db->update(array("ind_status" => "A"), $campo . '=' . $id);
                echo "updateSelRows('ativo',{$x});";
            }
            $x++;
        }

        echo "$.gritter.add({
		title:	'Registros Atualizados',
		text:	'Os registros selecionados foram Atualizados com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
    }

    private function depluralize($word) {

        $rules = array(
            'ss' => false,
            'os' => 'o',
            'as' => 'a',
            'res' => 'r',
            'ções' => 'cao',
            's' => '');
        // Loop through all the rules and do the replacement.
        foreach (array_keys($rules) as $key) {
            // If the end of the word doesn't match the key,
            // it's not a candidate for replacement. Move on
            // to the next plural ending.
            if (substr($word, (strlen($key) * -1)) != $key)
                continue;
            // If the value of the key is false, stop looping
            // and return the original version of the word.
            if ($key === false)
                return $word;
            // We've made it this far, so we can do the
            // replacement.
            return substr($word, 0, strlen($word) - strlen($key)) . $rules[$key];
        }
        return $word;
    }

}

?>
