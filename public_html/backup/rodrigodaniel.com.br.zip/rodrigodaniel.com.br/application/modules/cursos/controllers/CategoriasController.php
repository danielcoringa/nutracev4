<?php

class Cursos_CategoriasController extends Coringa_Controller_Cursos_Action {

    public function init() {
        $this->view->categorias = 'active open';
        $this->view->titleHeader = '<i class="glyphicon glyphicon-th-list"></i> Cadastro de Categorias';
        $this->view->bc = $this->getRequest()->getParams();
    }

    public function indexAction() {

        $this->view->scriptDefault = 'tables';
        $this->view->categoriasLista = 'active';
    }

    public function cadastroAction() {

        $this->view->categoriasCadastro = 'active';
        $this->view->scriptDefault = 'form_common';
        $db = new Cursos_Model_DbTable_Categoria();
        $request = $this->getRequest();
        $catPai = $db->getCategoriasPai();
        $this->view->catPai = $catPai;

        $edit = $request->getParam('editar');

        if ($edit > 0) {
            $this->view->dados = $db->getDados($edit);
        }
        if ($request->isPost()) {
            parent::norenderall();
            $dados = $request->getPost();
            if ($dados['cod_categoria'] > 0) {
                $insert = $db->atualizar($dados);

                echo "$.gritter.add({
		title:	'Registro Salvo',
		text:	'O registro foi alterado com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
            }
            else {
                $insert = $db->inserir($dados);
                echo "$('#cod_categoria').val({$insert});";

                echo "$.gritter.add({
		title:	'Registro Salvo',
		text:	'O registro foi realizado com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
            }
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

