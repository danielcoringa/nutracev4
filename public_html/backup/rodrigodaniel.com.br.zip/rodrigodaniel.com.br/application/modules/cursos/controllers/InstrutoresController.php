<?php

class Cursos_InstrutoresController extends Coringa_Controller_Cursos_Action {

    public function init() {
        $this->view->instrutor = 'active open';
        $this->view->titleHeader = '<i class="icon-adjust glyphicon glyphicon-pencil"></i> Cadastro de Instrutor';
        $this->view->bc = $this->getRequest()->getParams();
    }

    public function indexAction() {
        $this->view->scriptDefault = 'tables';
        $this->view->instrutorLista = 'active';
    }

    public function cadastroAction() {

        $this->view->instrutorCadastro = 'active';
        $this->view->scriptDefault = 'form_common';
        $db = new Cursos_Model_DbTable_Instrutor();
        $request = $this->getRequest();
        $edit = $request->getParam('editar');
        $dbe = new Cursos_Model_DbTable_Estados();
        $dbc = new Cursos_Model_DbTable_Cidades();
        $dbf = new Cursos_Model_DbTable_Formacao();

        $this->view->estados = $dbe->getEstados();
        $dados = $db->getDados($edit);
        $this->view->formacao = $dbf->getFormacao($dados['cod_instrutor']);
        if ($edit > 0) {
            $this->view->dados = $dados;

            $this->view->cidades = $dbc->getCidade($dados['ind_estado']);
        }
        if ($request->isPost()) {
            parent::norenderall();
            $dados = $request->getPost();
            if ($dados['cod_instrutor'] > 0) {
                $insert = $db->atualizar($dados);
                echo "$.gritter.add({
		title:	'Registro Salvo',
		text:	'O registro foi alterado com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
            }
            else {
                $insert = $db->inserir($dados);
                echo "$('#cod_instrutor').val({$insert});";

                echo "$.gritter.add({
		title:	'Registro Salvo',
		text:	'O registro foi realizado com sucesso.',
		image: 	'/img/cursos/demo/success.png',
		sticky: false
	});	";
            }
        }
    }

    public function formacaoAction() {
        parent::norenderall();
        $request = $this->getRequest();
        $dados = $request->getPost();
        $db = new Cursos_Model_DbTable_Formacao();
        if ($dados['cod_instrutor'] < 1) {
            echo "alert('É necessário salvar o registro antes de incluir.');";
            exit;
        }
        else {
            $result = $db->inserir($dados);
        }

        if ($result > 0) {
            echo $db->getFormacao($dados['cod_instrutor']);
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

