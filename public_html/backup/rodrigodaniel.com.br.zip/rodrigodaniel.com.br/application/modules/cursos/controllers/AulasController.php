<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Cursos_AulasController extends Coringa_Controller_Cursos_Action {

    public function init() {

    }

    public function indexAction() {

    }

}
