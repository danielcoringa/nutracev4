<?php

/**
 * Description of Security
 * @category   PublicAnuncios
 * @package    Coringa_Controller
 * @copyright  Copyright (c) 2013-2013 CoringaSistemas INC (http://www.coringasistemas.com.br)
 */
class Cursos_Model_DbTable_Instrutor extends Zend_Db_Table_Abstract {

    protected $_name = 'tab_web_instrutor';
    protected $_primary = 'cod_instrutor';

    public function gridList() {
        $select = $this->select();
        $select->setIntegrityCheck(false);
        $select->from(array("twi" => "tab_web_instrutor"));
        //$select->joinLeft(array("twsc" => "tab_web_instrutor"), "twsc.cod_instrutor=twc.cod_sub_instrutor", "twsc.nom_instrutor AS nom_instrutor_pai");
        $select->where("twi.ind_status=?", "A");
        return $this->fetchAll($select);
    }

    public function inserir($dados) {
        $data['nom_instrutor'] = $dados['nom_instrutor'];
        $data['ind_estado'] = $dados['ind_estado'];
        $data['ind_cidade'] = $dados['ind_cidade'];
        $data['ind_pais'] = $dados['ind_pais'];
        $data['end_email'] = $dados['end_email'];
        $data['end_url'] = $dados['end_url'];
        $data['num_telefone'] = $dados['num_telefone'];


        return $this->insert($data);
    }

    public function atualizar($dados) {
        $data = array();
        $cod_instrutor = $dados['cod_instrutor'];
        $data['nom_instrutor'] = $dados['nom_instrutor'];
        $data['ind_estado'] = $dados['ind_estado'];
        $data['ind_cidade'] = $dados['ind_cidade'];
        $data['ind_pais'] = $dados['ind_pais'];
        $data['end_email'] = $dados['end_email'];
        $data['end_url'] = $dados['end_url'];
        $data['num_telefone'] = $dados['num_telefone'];
        return $this->update($data, "cod_instrutor=" . $cod_instrutor);
    }

    public function getDados($where) {
        if (isset($where)) {
            $select = $this->select();
            $select->where("cod_instrutor=?", $where);
            return $this->fetchRow($select);
        }
    }

    public function getSelect() {
        $select = $this->select();
        $select->where("ind_status='A'");
        $select->order("nom_instrutor ASC");
        return $this->fetchAll($select)->toArray();
    }

    public function grid($echo) {
        $iTotal = 0;
        $iFilteredTotal = 0;
        $output = array(
            "sEcho" => intval($echo),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array()
        );
        $retorno = $this->gridList('A');
        foreach ($retorno as $row) {
            $rows = array(
                '<input type="checkbox" class="optcheck" value="' . $row['cod_instrutor'] . '" />',
                $row['nom_instrutor'],
                $row['des_instrutor'],
                $row['ind_status']
            );
            $output['aaData'][] = $rows;
        }
        return json_encode($output);
    }

}
