<?php

/**
 * Description of Security
 * @category   PublicAnuncios
 * @package    Coringa_Controller
 * @copyright  Copyright (c) 2013-2013 CoringaSistemas INC (http://www.coringasistemas.com.br)
 */
class Cursos_Model_DbTable_Formacao extends Zend_Db_Table_Abstract {

    protected $_name = 'tab_web_formacao';
    protected $_primary = 'cod_formacao';

    public function inserir($dados) {
        $data['cod_instrutor'] = $dados['cod_instrutor'];
        $data['nom_curso'] = $dados['nom_curso'];
        $data['des_curso'] = $dados['des_curso'];
        $data['dta_inicio'] = $this->dateFormat($dados['dta_inicio']);
        $data['dta_termino'] = $this->dateFormat($dados['dta_termino']);
        $data['nom_instituicao'] = $dados['nom_instituicao'];
        return $this->insert($data);
    }

    public function getDados($where) {
        $select = $this->select();
        $select->where($where);
        return $this->fetchAll($select)->toArray();
    }

    public function getFormacao($cod) {
        if ($cod > 0) {
            $select = $this->select();
            $select->where("cod_instrutor=" . $cod);
            $return = $this->fetchAll($select)->toArray();
            if (count($return) > 0) {
                foreach ($return as $row) {
                    $layout.= $this->layout($row);
                }
                return $layout;
            }
            else {
                return "<div class='alert alert-info'>
                <span class='close'>x</span>
                <h4 class='alert-heading'><span class='glyphicon glyphicon-info-sign'></span> Ainda não há nenhuma formação ou curso adicionado.</h4>
                <p>Clique no botão Adicionar Formação.</p>
            </div>";
            }
        }
        else {
            return "<div class='alert alert-info'>
                <span class='close'>x</span>
                <h4 class='alert-heading'><span class='glyphicon glyphicon-info-sign'></span> Ainda não há nenhuma formação ou curso adicionado.</h4>
                <p>Clique no botão Adicionar Formação.</p>
            </div>";
        }
    }

    function dateFormat($data) {
        $d = explode("/", $data);
        return $d[1] . '-' . $d[0] . '-1';
    }

    function layout($row) {

        setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8", "portuguese");
        date_default_timezone_set('America/Sao_Paulo');
        $html = '<div class="new-update clearfix">';
        $html.= '<i class="icon-ok-sign"></i>';
        $html.= '<div class="update-done">';
        $html.= '<a title="" href="#"><strong>' . $row['nom_curso'] . '</strong></a>';
        $html.= '<span>' . $row['des_curso'] . '</span>';
        $html.= '</div>';
        $html.= '<div class="update-date"><span class="update-day">' . date("M", strtotime($row['dta_inicio'])) . '</span>' . date("Y", strtotime($row['dta_inicio'])) . '</div>';
        $html.= '</div>';

        return $html;
    }

}
