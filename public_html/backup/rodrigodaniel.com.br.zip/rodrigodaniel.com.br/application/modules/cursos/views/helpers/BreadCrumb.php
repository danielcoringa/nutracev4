<?php

class Zend_View_Helper_BreadCrumb extends Zend_View_Helper_Abstract {
    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    public function breadCrumb($var) {
        $controle = $var['controller'];
        $action = '<a href = "/' . $controle . '" title = "Voltar para a lista de ' . ucfirst($controle) . '">' . ucfirst($controle) . '</a>';
        $home = '<a href = "/" title = "Voltar para o Dashboard" class = "tip-bottom"><i class = "glyphicon glyphicon-home"></i> Dashboard</a>';
        $atual = '<a href = "#" class = "current">Cadastro</a>';
        return $home . $action . $atual;
        /* '

          <a href = "/categorias" title = "Voltar para a lista de Categorias">Categorias</a>
          <a href = "#" class = "current">Cadastro</a>';
         *
         */
    }

}
