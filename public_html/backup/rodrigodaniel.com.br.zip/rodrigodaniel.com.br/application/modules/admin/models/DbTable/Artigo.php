<?php

/**
 * Description of Security
 * @category   PublicAnuncios
 * @package    Coringa_Controller
 * @copyright  Copyright (c) 2013-2013 CoringaSistemas INC (http://www.coringasistemas.com.br)
 */
class Admin_Model_DbTable_Artigo extends Zend_Db_Table_Abstract {

    protected $_name = 'tab_web_artigo';
    protected $_primary = 'cod_artigo';

    public function gridList() {
        $select = $this->select();
        $select->where("ind_status=?", "A");
        return $this->fetchAll($select);
    }

    public function inserir($dados) {
        $data = array();
        $data['nom_artigo'] = $dados['nom_artigo'];
        $data['des_artigo'] = $dados['des_artigo'];
        $data['tipo_artigo'] = $dados['tipo_artigo'];
        $data['dta_publicacao'] = $this->dataFormat($dados['dta_publicacao']);
        $data['dta_expiracao'] = $this->dataFormat($dados['dta_expiracao']);

//$data['tag_artigo'] = $dados['tag_artigo'];
        $data['ind_review'] = $dados['ind_review'];
        $retorno = $this->insert($data);
        $db = new Admin_Model_DbTable_CategoriaArtigo();
        foreach ($dados['cod_categoria'] as $categoria) {
            $db->insert(array("cod_categoria" => $categoria, "cod_artigo" => $retorno));
        }

        $dbc = new Admin_Model_DbTable_Conf_Artigo();
        $datac['cod_artigo'] = $retorno;
        $datac['bg_image'] = $dados['bg_image'];
        $datac['bg_color'] = $dados['bg_color'];
        $datac['bg_repeat'] = $dados['bg_repeat'];
        $datac['bg_position'] = $dados['bg_position'];
        $datac['bg_size'] = $dados['bg_size'];
        if (isset($dados['sidebar']) && $dados['sidebar'] != '') {
            $datac['sidebar'] = $dados['sidebar'];
        }
        else {
            $datac['sidebar'] = 'E';
        }

        $datac['bgcolor_meta'] = $dados['bgcolor_meta'];
        $datac['bg_pattern'] = $dados['bg_pattern'];
        $dbc->insert($datac);

// Verifica se o modo é Galeria
        if ($dados['tipo_artigo'] == 'image') {
            $dbi = new Admin_Model_DbTable_Imagem();
            $dadosi['img_name'] = $dados['img_name'];
            $dadosi['img_tipo'] = $dados['img_tipo'];
            if (isset($dados['img_thumb'])) {
                $dadosi['img_thumb'] = $dados['img_thumb'];
            }
            $dadosi['cod_artigo'] = $retorno;
            $dbi->insert($dadosi);
        }
        if ($dados['tipo_artigo'] == 'gallery') {
            $dbg = new Admin_Model_DbTable_Galeria();
            $images = $dados['img_gallery'];
            $description = $dados['img_description'];
            foreach ($images as $k => $v) {
                $arq = explode('/', $images[$k]);
                $nome = $arq[4];
                $folder = str_replace($nome, '', $images[$k]);
                $ext = substr($nome, -3);
                $datag['nom_imagem'] = str_replace('.' . $ext, '', $nome);
                $datag['ext_imagem'] = $ext;
                $datag['des_imagem'] = $description[$k];
                $datag['nom_pasta'] = $folder;
                $datag['cod_artigo'] = $retorno;
                $dbg->insert($datag);
            }
        }
//        }
//        if ($dados['tipo_artigo'] == 'video') {
//            $dbv = new Admin_Model_DbTable_Video();
//            $datav['cod_artigo'] = $retorno;
//            $datav['id_video'] = $dados['id_video'];
//            $datav['id_file'] = $dados['id_file'];
//            $datav['tipo_video'] = $dados['tipo_video'];
//            $dbv->insert($datav);
//        }
        if ($dados['tipo_artigo'] == 'audio') {
            $dba = new Admin_Model_DbTable_Audio();
            $dataa['cod_artigo'] = $retorno;
            $dataa['id_musica'] = $dados['id_audio'];
            $dataa['nom_musica'] = $dados['nom_musica'];
            $dba->insert($dataa);
        }
        if ($dados['ind_review'] == 'A') {
            $dbr = new Admin_Model_DbTable_Review();
            $dadosr['cod_artigo'] = $retorno;
            $dadosr['nom_review'] = $dados['nom_review'];
            $dadosr['des_review'] = $dados['des_review'];
            $dadosr['star_color'] = $dados['star_color'];
            $dadosr['score_color'] = $dados['score_color'];
            $dadosr['criterio_one'] = $dados['criterio_one'];
            $dadosr['score_one'] = $dados['score_one'];
            $dadosr['criterio_two'] = $dados['criterio_two'];
            $dadosr['score_two'] = $dados['score_two'];
            $dadosr['criterio_three'] = $dados['criterio_three'];
            $dadosr['score_three'] = $dados['score_three'];
            $dadosr['criterio_four'] = $dados['criterio_four'];
            $dadosr['score_four'] = $dados['score_four'];
            $dadosr['criterio_five'] = $dados['criterio_five'];
            $dadosr['score_five'] = $dados['score_five'];
            $dadosr['total_score'] = ($dados['score_five'] + $dados['score_four'] + $dados['score_three'] + $dados['score_two'] + $dados['score_one']) / 5;
            $dbr->insert($dadosr);
        }
        return $retorno;
    }

    public function atualizar($dados) {
        $data = array();
        $data['nom_artigo'] = $dados['nom_artigo'];
        $data['des_artigo'] = $dados['des_artigo'];
        $data['tipo_artigo'] = $dados['tipo_artigo'];
        $data['tag_artigo'] = $dados['tag_artigo'];
        $data['ind_review'] = $dados['ind_review'];
        $retorno = $this->update($data, "cod_artigo=" . $dados['cod_artigo']);
        $db = new Admin_Model_DbTable_CategoriaArtigo();
        $db->delete("cod_artigo=" . $dados['cod_artigo']);
        foreach ($dados['cod_categoria'] as $categoria) {
            $db->insert(array("cod_categoria" => $categoria, "cod_artigo" => $dados['cod_artigo']));
        }
        if ($dados['tipo_artigo'] == 'gallery') {
            $dbg = new Admin_Model_DbTable_Galeria();
            $images = $dados['img_galeria'];
            foreach ($images as $img) {
                $arq = explode('/', $img);
                $nome = $arq[5];
                $folder = str_replace($nome, '', $img);
                $ext = substr($nome, -3);
                $datag['nom_imagem'] = str_replace('.' . $ext, '', $nome);
                $datag['ext_imagem'] = $ext;
                $datag['nom_pasta'] = $folder;
                $datag['cod_artigo'] = $dados['cod_artigo'];
                $dbg->insert($datag);
            }
        }
        if ($dados['tipo_artigo'] == 'video') {
            $dbv = new Admin_Model_DbTable_Video();
            if (isset($dados['id_video'])) {
                $dbv->delete("cod_artigo=" . $dados['cod_artigo']);
                $datav['cod_artigo'] = $dados['cod_artigo'];
                $datav['id_video'] = $dados['id_video'];
                $datav['id_file'] = $dados['id_file'];
                $datav['tipo_video'] = $dados['tipo_video'];
                $dbv->insert($datav);
            }
        }
        if ($dados['tipo_artigo'] == 'audio') {
            $dba = new Admin_Model_DbTable_Audio();
            if (isset($dados['id_audio'])) {
                $dba->delete("cod_artigo=" . $dados['cod_artigo']);
                $dataa['cod_artigo'] = $dados['cod_artigo'];
                $dataa['id_musica'] = $dados['id_audio'];
                $dataa['nom_musica'] = $dados['nom_musica'];
                $dba->insert($dataa);
            }
        }
        if ($dados['ind_review'] == 'A') {
            $dbr = new Admin_Model_DbTable_Review();
            $select = $dbr->select();
            $select->where("cod_artigo=" . $dados['cod_artigo']);
            $result = $dbr->fetchRow($select);
            if (count($result) > 0) {
                $dadosr['nom_review'] = $dados['nom_review'];
                $dadosr['star_color'] = $dados['star_color'];
                $dadosr['score_color'] = $dados['score_color'];
                $dadosr['criterio_one'] = $dados['criterio_one'];
                $dadosr['score_one'] = $dados['score_one'];
                $dadosr['criterio_two'] = $dados['criterio_two'];
                $dadosr['score_two'] = $dados['score_two'];
                $dadosr['criterio_three'] = $dados['criterio_three'];
                $dadosr['score_three'] = $dados['score_three'];
                $dadosr['criterio_four'] = $dados['criterio_four'];
                $dadosr['score_four'] = $dados['score_four'];
                $dadosr['criterio_five'] = $dados['criterio_five'];
                $dadosr['score_five'] = $dados['score_five'];
                $dadosr['total_score'] = ($dados['score_five'] + $dados['score_four'] + $dados['score_three'] + $dados['score_two'] + $dados['score_one']) / 5;
                $dbr->update($dadosr, 'cod_artigo=' . $dados['cod_artigo']);
            }
            else {
                $dadosr['cod_artigo'] = $dados['cod_artigo'];
                $dadosr['nom_review'] = $dados['nom_review'];
                $dadosr['star_color'] = $dados['star_color'];
                $dadosr['score_color'] = $dados['score_color'];
                $dadosr['criterio_one'] = $dados['criterio_one'];
                $dadosr['score_one'] = $dados['score_one'];
                $dadosr['criterio_two'] = $dados['criterio_two'];
                $dadosr['score_two'] = $dados['score_two'];
                $dadosr['criterio_three'] = $dados['criterio_three'];
                $dadosr['score_three'] = $dados['score_three'];
                $dadosr['criterio_four'] = $dados['criterio_four'];
                $dadosr['score_four'] = $dados['score_four'];
                $dadosr['criterio_five'] = $dados['criterio_five'];
                $dadosr['score_five'] = $dados['score_five'];
                $dadosr['total_score'] = ($dados['score_five'] + $dados['score_four'] + $dados['score_three'] + $dados['score_two'] + $dados['score_one']) / 5;
                $dbr->insert($dadosr);
            }
        }
        return $retorno;
    }

    public function getDados($where = '') {
        $select = $this->select();
        $select->where("cod_artigo=?", $where);
        return $this->fetchRow($select)->toArray();
    }

    public function getSelect() {
        return $this->fetchAll('ind_status="A"')->toArray();
    }

    public function getArtigos() {
        $select = $this->select();
        $select->where("ind_status='A'");
        $select->limit(6);
        $select->order("cod_artigo DESC");
        return $this->fetchAll($select)->toArray();
    }

    public function grid($echo) {
        $iTotal = 0;
        $iFilteredTotal = 0;
        $output = array(
            "sEcho" => intval($echo),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array()
        );
        $retorno = $this->gridList('A');
        foreach ($retorno as $row) {
            $grid = new Admin_Model_Grid();
            $rows = array(
                '<input type="checkbox" class="optcheck" value="' . $row['cod_artigo'] . '" />',
                $row['nom_artigo'],
                $grid->truncate($row['des_artigo'], 100),
                $grid->getCategoria($row['cod_artigo']),
                $grid->getTipoArtigo($row['tipo_artigo']),
                $grid->datahora($row['dta_artigo']),
                $grid->ativo($row['ind_status'])
            );
            $output['aaData'][] = $rows;
        }
        return json_encode($output);
    }

    public function setCount($cod) {
        $select = $this->select();
        $select->where('cod_artigo=?', $cod);
        $result = $this->fetchRow($select);
        $count = $result['num_views'];
        $dados['num_views'] = $count + 1;
        $this->update($dados, 'cod_artigo=' . $cod);
    }

    private function dataFormat($date) {
        $dh = explode(" ", $date);
        list($dt, $h) = $dh;
        $dt = explode("/", $dt);
        list($d, $m, $y) = $dt;

        return ("{$y}-{$m}-{$d} {$h}:00");
    }

}
