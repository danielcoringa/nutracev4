<?php

class Admin_IndexController extends Zend_Controller_Action {

    public function init() {
        /* Initialize action controller here */
        $this->view->title = 'Dashboard';
    }

    public function indexAction() {
        // action body
    }

    public function uiElementsAction() {

    }

    public function loginAction() {
        
    }

}
