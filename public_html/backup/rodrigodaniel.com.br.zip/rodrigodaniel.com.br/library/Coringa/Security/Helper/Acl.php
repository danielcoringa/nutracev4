<?php

class Coringa_Security_Helper_Acl extends Zend_Controller_Action_Helper_Abstract {

    //the acl object
    public $acl;

    //the constructor of the our ACL
    public function __construct() {
        $this->acl = new Zend_Acl();
        $this->auth = new Zend_Session_Namespace("auth");
        $this->userid = $this->auth->user_id;
        if ($this->userid == '') {
            $this->userid = 0;
        }

        $params = array('host' => 'localhost',
            'username' => 'rodrigod_alicerc',
            'password' => 'Str0ng@123',
            'dbname' => 'rodrigod_alicerce');
        $this->_db = Zend_Db::factory('PDO_MYSQL', $params);
    }

    private function montaAcl() {

    }

    //function that sets roles for the people
    public function setRoles() {
        $vuser = $this->_db->select();

        $vuser->from(array("tu" => "tab_web_usuario"));
        $vuser->joinInner(array("tg" => "tab_web_grupo"), "tg.cod_grupo=tu.cod_grupo");
        $vuser->where("tu.cod_usuario = " . $this->userid);
        $this->r = $this->_db->fetchAll($vuser);
        // Verifica o tipo de acesso
        if (count($this->r) > 0) {
            $role = strtolower($this->r[0]['nom_grupo']);
        }
        else {
            $role = 'visitante';
        }

        $this->role = $role;
        $this->acl->addRole(new Zend_Acl_Role($role));
    }

    //function that set the resources to be accessed on the site
    public function setResources() {

        $this->montaAcl();
        if ($this->role == 'administrador') {
            $this->acl->add(new Zend_Acl_Resource('admin'));
            $this->acl->add(new Zend_Acl_Resource('admin:index'));
            $this->acl->add(new Zend_Acl_Resource('admin:artigos'));
            $this->acl->add(new Zend_Acl_Resource('admin:configuracoes'));
            $this->acl->add(new Zend_Acl_Resource('admin:json'));
            $this->acl->add(new Zend_Acl_Resource('alicerce'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:index'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:ajax'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:error'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:clientes'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:grid'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:equipamentos'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:locacoes'));

            $this->acl->add(new Zend_Acl_Resource('alicerce:fornecedores'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:obras'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:relatorios'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:pdf'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:usuarios'));
            $this->acl->add(new Zend_Acl_Resource('alicerce:configuracoes'));

            $this->acl->add(new Zend_Acl_Resource('cursos'));
            $this->acl->add(new Zend_Acl_Resource('cursos:index'));
            $this->acl->add(new Zend_Acl_Resource('cursos:categorias'));
            $this->acl->add(new Zend_Acl_Resource('cursos:instrutores'));
            $this->acl->add(new Zend_Acl_Resource('cursos:alunos'));
            $this->acl->add(new Zend_Acl_Resource('cursos:json'));
            $this->acl->add(new Zend_Acl_Resource('cursos:grid'));
            $this->acl->add(new Zend_Acl_Resource('cursos:error'));
            $this->acl->add(new Zend_Acl_Resource('cursos:aulas'));
        }



        $this->acl->add(new Zend_Acl_Resource('blog'));
        $this->acl->add(new Zend_Acl_Resource('blog:index'));
        $this->acl->add(new Zend_Acl_Resource('blog:artigos'));
        $this->acl->add(new Zend_Acl_Resource('blog:quem-somos'));
        $this->acl->add(new Zend_Acl_Resource('blog:contato'));
        $this->acl->add(new Zend_Acl_Resource('blog:error'));


        $this->acl->add(new Zend_Acl_Resource('login'));
        $this->acl->add(new Zend_Acl_Resource('login:index'));


        $this->acl->add(new Zend_Acl_Resource('alicerce:extras'));
        $this->acl->add(new Zend_Acl_Resource('alicerce:minify'));


        $this->acl->add(new Zend_Acl_Resource('site'));
        $this->acl->add(new Zend_Acl_Resource('site:index'));


        $this->acl->add(new Zend_Acl_Resource('anuncios'));
        $this->acl->add(new Zend_Acl_Resource('anuncios:index'));
        $this->acl->add(new Zend_Acl_Resource('anuncios:error'));
    }

    //function that sets the privileges for the different roles
    public function setPrivileges() {


        if ($this->role == 'administrador') {


            $this->acl->allow($this->role, 'admin');
            $this->acl->allow($this->role, 'admin:index');
            $this->acl->allow($this->role, 'admin:artigos');
            $this->acl->allow($this->role, 'admin:configuracoes');
            $this->acl->allow($this->role, 'admin:json');
            $this->acl->allow($this->role, 'alicerce');
            $this->acl->allow($this->role, 'alicerce:index');
            $this->acl->allow($this->role, 'alicerce:ajax');
            $this->acl->allow($this->role, 'alicerce:error');
            $this->acl->allow($this->role, 'alicerce:clientes');
            $this->acl->allow($this->role, 'alicerce:grid');

            $this->acl->allow($this->role, 'alicerce:equipamentos');
            $this->acl->allow($this->role, 'alicerce:locacoes');
            $this->acl->allow($this->role, 'alicerce:fornecedores');
            $this->acl->allow($this->role, 'alicerce:obras');
            $this->acl->allow($this->role, 'alicerce:relatorios');
            $this->acl->allow($this->role, 'alicerce:pdf');
            $this->acl->allow($this->role, 'alicerce:usuarios');
            $this->acl->allow($this->role, 'alicerce:configuracoes');

            $this->acl->allow($this->role, 'cursos');
            $this->acl->allow($this->role, 'cursos:index');
            $this->acl->allow($this->role, 'cursos:categorias');
            $this->acl->allow($this->role, 'cursos:grid');
            $this->acl->allow($this->role, 'cursos:instrutores');
            $this->acl->allow($this->role, 'cursos:json');
            $this->acl->allow($this->role, 'cursos:alunos');
            $this->acl->allow($this->role, 'cursos:error');
            $this->acl->allow($this->role, 'cursos:aulas');
        }

        $this->acl->allow($this->role, 'site');
        $this->acl->allow($this->role, 'site:index');
        $this->acl->allow($this->role, 'blog');
        $this->acl->allow($this->role, 'blog:index');
        $this->acl->allow($this->role, 'blog:artigos');
        $this->acl->allow($this->role, 'blog:quem-somos');
        $this->acl->allow($this->role, 'blog:error');
        $this->acl->allow($this->role, 'blog:contato');
        $this->acl->allow($this->role, 'login');
        $this->acl->allow($this->role, 'login:index');
        $this->acl->allow($this->role, 'alicerce:extras');
        $this->acl->allow($this->role, 'alicerce:minify');


        $this->acl->allow($this->role, 'anuncios');
        $this->acl->allow($this->role, 'anuncios:index');
        $this->acl->allow($this->role, 'anuncios:error');






        //print_r($this->acl);exit;
    }

    public function setAcl() {
        Zend_Registry::set('acl', $this->acl);
    }

}
