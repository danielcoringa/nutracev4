<?php

/**
 * Description of Security
 * @category   PublicAnuncios
 * @package    Coringa_Controller
 * @copyright  Copyright (c) 2013-2013 CoringaSistemas INC (http://www.coringasistemas.com.br)
 */
class Coringa_Controller_Admin_Action extends Zend_Controller_Action {

    public function init() {
        $dbc = new Admin_Model_DbTable_Conf_Geral();
        $this->view->conf = $dbc->getConf();
        $this->view->headScript()->appendFile('/admin/scripts/javascript?mode=basic');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.hashchange.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.idle-timer.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.selectboxes.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.plusplus.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.jgrowl.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.scrollTo.js');
        $this->view->headScript()->appendFile('http://malsup.github.com/jquery.form.js');

        $this->view->headScript()->appendFile('/js/admin/mylibs/tinyscrollbar.js');
        $this->view->headScript()->appendFile('/js/admin/jquery.maskMoney.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.ui.touch-punch.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery.ui.multiaccordion.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/number-functions.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.autosize.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.checkbox.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.chosen.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.cleditor.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.colorpicker.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.ellipsis.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.fileinput.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.fullcalendar.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.maskedinput.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.mousewheel.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.placeholder.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.pwdmeter.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.ui.datetimepicker.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.ui.spinner.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.validate.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/uploader/plupload.full.min.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/uploader/jquery.plupload.queue/jquery.plupload.queue.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/charts/jquery.flot.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/charts/jquery.flot.orderBars.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/charts/jquery.flot.pie.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/charts/jquery.flot.resize.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/explorer/jquery.elfinder.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/fullstats/jquery.css-transform.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/fullstats/jquery.animate-css-rotate-scale.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/fullstats/jquery.sparkline.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/syntaxhighlighter/shCore.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/syntaxhighlighter/shAutoloader.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/syntaxhighlighter/shBrushJScript.js');
        $this->view->headScript()->appendFile('/js/admin/jquery.maskMoney.js');

        $this->view->headScript()->appendFile('/js/admin/mylibs/dynamic-tables/jquery.dataTables.js');

        $this->view->headScript()->appendFile('/js/admin/mylibs/dynamic-tables/jquery.dataTables.tableTools.zeroClipboard.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/forms/jquery.ui.datetimepicker.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/dynamic-tables/jquery.dataTables.tableTools.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/gallery/jquery.fancybox.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/tooltips/jquery.tipsy.js');
        //$this->view->headScript()->appendFile('/js/admin/jquery.cookie.js');
        $this->view->headScript()->appendFile('/js/admin/mylibs/jquery_cookie.js');
        $this->view->headScript()->appendFile('/js/admin/plugins.js');
        $this->view->headScript()->appendFile('/js/admin/jwplayer.js');
        $this->view->headScript()->appendFile('/js/admin/jwplayer.html5.js');
        $this->view->headScript()->appendFile('/js/admin/script.js');
    }

    public function noRender() {
        $dbc = new Admin_Model_DbTable_Conf_Geral();
        $this->view->conf = $dbc->getConf();
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(TRUE);
    }

}

?>
